# Tuit — Backend Setup & Deployment Guide

## What this server does

1. **Auth** — Schools sign up, log in, sessions are token-based
2. **Students** — Each student gets a unique payment reference (e.g. `TUT-AB12CD34`)
3. **Flutterwave webhook** (`POST /webhooks/flutterwave`) — Called instantly when a parent pays via Flutterwave. Tuit auto-logs: student name, amount, date/time, parent name, payment method
4. **Mono webhook** (`POST /webhooks/mono`) — Called when a credit hits the school's linked bank account. Tuit matches the transfer to a student using the payment reference or name in the narration
5. **Manual cash** — Only cash payments need manual entry

---

## Quick Start (Local)

```bash
cd tuit
npm install
node server.js
# Server runs at http://localhost:3000
```

---

## Environment Variables (create a `.env` file)

```env
PORT=3000
FLW_SECRET_HASH=your_flutterwave_secret_hash_from_dashboard
MONO_WEBHOOK_SECRET=your_mono_webhook_secret
JWT_SECRET=a_random_long_string_for_signing_tokens
FLW_SECRET_KEY=FLWSECK_TEST-xxxxxxxxxxxxxxxx
```

---

## Deployment (Render.com — recommended, free tier)

1. Push this folder to a GitHub repo
2. Go to https://render.com → New Web Service → connect your repo
3. Build command: `npm install`
4. Start command: `node server.js`
5. Add your environment variables in the Render dashboard
6. Your server URL will be: `https://your-app.onrender.com`

---

## Flutterwave Setup

1. Log in to https://dashboard.flutterwave.com
2. Go to **Settings → Webhooks**
3. Set webhook URL to: `https://your-server.com/webhooks/flutterwave`
4. Set a **Secret Hash** (any string you choose) and copy it into your `.env` as `FLW_SECRET_HASH`
5. In Tuit → Integrations, paste your **Flutterwave Public Key** and enable the toggle

**How it works:**
- Each student has a unique `paymentRef` (e.g. `TUT-AB12CD34`)
- Click "Get Link" on a student → share that Flutterwave checkout link with the parent
- Parent pays by card, bank transfer, or USSD
- Flutterwave sends a webhook to your server → Tuit matches the `tx_ref` to the student → payment is auto-logged instantly

---

## Mono Setup

1. Sign up at https://mono.co (or contact them for business access)
2. The school connects their bank account via Mono Connect widget
3. You receive a Mono `account_id` — enter this in Tuit → Integrations
4. Set your webhook URL in the Mono dashboard: `https://your-server.com/webhooks/mono`
5. Copy your Mono webhook secret into `.env` as `MONO_WEBHOOK_SECRET`

**How auto-matching works:**
When a parent makes a direct bank transfer, Tuit tries to identify the student from the transfer narration:
- **Best match** — parent includes the student's payment reference in the narration (e.g. "School fees TUT-AB12CD34")
- **Name match** — narration contains the student's first + last name
- **Parent name match** — narration contains the parent's name
- **No match** — payment is logged as "Unmatched — Review Required" and the school can manually assign it

**Tip:** Tell parents to always include the payment reference in their transfer narration.

---

## For Cash Payments

Cash payments are the only ones that need manual entry. Click "Record Cash" in the dashboard, select the student, enter the amount and date.

---

## Database

Currently uses a `db.json` flat file. For production with many schools, replace with:
- **PostgreSQL** (recommended) via `pg` package
- **MongoDB** via `mongoose`
- **PlanetScale** (MySQL-compatible, free tier)

The DB interface in `server.js` (`readDB` / `writeDB`) is intentionally simple to make this swap easy.

---

## Webhook Testing (local)

Use [ngrok](https://ngrok.com) to expose your local server to the internet for testing:

```bash
ngrok http 3000
# Copy the https URL → use as your webhook URL in Flutterwave/Mono dashboards
```
