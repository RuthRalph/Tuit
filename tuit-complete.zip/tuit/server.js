/**
 * TUIT BACKEND SERVER
 * Handles: Auth, Students, Payments, Flutterwave webhooks, Mono webhooks
 * Database: JSON flat-file (swap for PostgreSQL/MongoDB in production)
 */

const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// ── Config (move to .env in production) ──────────────────────────────────────
const CONFIG = {
  FLW_SECRET_HASH: process.env.FLW_SECRET_HASH || 'your_flutterwave_secret_hash',
  MONO_WEBHOOK_SECRET: process.env.MONO_WEBHOOK_SECRET || 'your_mono_webhook_secret',
  JWT_SECRET: process.env.JWT_SECRET || 'tuit_jwt_secret_change_in_prod',
  FLW_SECRET_KEY: process.env.FLW_SECRET_KEY || 'FLWSECK_TEST-xxxx',
};

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(cors());
// Raw body needed for webhook signature verification — must come before json()
app.use('/webhooks', express.raw({ type: 'application/json' }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── JSON File Database ────────────────────────────────────────────────────────
const DB_PATH = path.join(__dirname, 'db.json');

function readDB() {
  if (!fs.existsSync(DB_PATH)) {
    const seed = { schools: [], students: [], payments: [], sessions: [] };
    fs.writeFileSync(DB_PATH, JSON.stringify(seed, null, 2));
    return seed;
  }
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}

function writeDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function uid() {
  return crypto.randomBytes(8).toString('hex');
}

// ── Auth Middleware ───────────────────────────────────────────────────────────
function requireAuth(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'No token provided' });
  const db = readDB();
  const session = db.sessions.find(s => s.token === token);
  if (!session) return res.status(401).json({ error: 'Invalid or expired token' });
  req.schoolId = session.schoolId;
  next();
}

// ═══════════════════════════════════════════════════════════
// AUTH ROUTES
// ═══════════════════════════════════════════════════════════

// Sign Up
app.post('/api/auth/signup', (req, res) => {
  const { name, role, schoolName, email, password } = req.body;
  if (!name || !role || !schoolName || !email || !password)
    return res.status(400).json({ error: 'All fields are required.' });
  if (password.length < 6)
    return res.status(400).json({ error: 'Password must be at least 6 characters.' });

  const db = readDB();
  if (db.schools.find(s => s.email === email.toLowerCase()))
    return res.status(409).json({ error: 'An account with this email already exists.' });

  const school = {
    id: uid(),
    name,
    role,
    schoolName,
    email: email.toLowerCase(),
    passwordHash: crypto.createHash('sha256').update(password).digest('hex'),
    flutterwaveEnabled: false,
    monoEnabled: false,
    flwPublicKey: '',
    monoAccountId: '',
    createdAt: new Date().toISOString(),
  };
  db.schools.push(school);

  const token = crypto.randomBytes(32).toString('hex');
  db.sessions.push({ token, schoolId: school.id, createdAt: new Date().toISOString() });
  writeDB(db);

  res.json({ token, school: sanitizeSchool(school) });
});

// Login
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const db = readDB();
  const school = db.schools.find(s => s.email === email?.toLowerCase());
  const hash = crypto.createHash('sha256').update(password || '').digest('hex');
  if (!school || school.passwordHash !== hash)
    return res.status(401).json({ error: 'Incorrect email or password.' });

  const token = crypto.randomBytes(32).toString('hex');
  db.sessions.push({ token, schoolId: school.id, createdAt: new Date().toISOString() });
  writeDB(db);

  res.json({ token, school: sanitizeSchool(school) });
});

// Get current school profile
app.get('/api/auth/me', requireAuth, (req, res) => {
  const db = readDB();
  const school = db.schools.find(s => s.id === req.schoolId);
  if (!school) return res.status(404).json({ error: 'School not found' });
  res.json({ school: sanitizeSchool(school) });
});

// Logout
app.post('/api/auth/logout', requireAuth, (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  const db = readDB();
  db.sessions = db.sessions.filter(s => s.token !== token);
  writeDB(db);
  res.json({ ok: true });
});

// Update integration settings
app.patch('/api/auth/settings', requireAuth, (req, res) => {
  const { flutterwaveEnabled, monoEnabled, flwPublicKey, monoAccountId } = req.body;
  const db = readDB();
  const school = db.schools.find(s => s.id === req.schoolId);
  if (!school) return res.status(404).json({ error: 'Not found' });
  if (flutterwaveEnabled !== undefined) school.flutterwaveEnabled = flutterwaveEnabled;
  if (monoEnabled !== undefined) school.monoEnabled = monoEnabled;
  if (flwPublicKey !== undefined) school.flwPublicKey = flwPublicKey;
  if (monoAccountId !== undefined) school.monoAccountId = monoAccountId;
  writeDB(db);
  res.json({ school: sanitizeSchool(school) });
});

function sanitizeSchool(s) {
  const { passwordHash, ...safe } = s;
  return safe;
}

// ═══════════════════════════════════════════════════════════
// STUDENT ROUTES
// ═══════════════════════════════════════════════════════════

app.get('/api/students', requireAuth, (req, res) => {
  const db = readDB();
  const students = db.students.filter(s => s.schoolId === req.schoolId);
  res.json({ students });
});

app.post('/api/students', requireAuth, (req, res) => {
  const { firstName, lastName, className, termFee, parentName, parentPhone } = req.body;
  if (!firstName || !lastName || !className || !termFee)
    return res.status(400).json({ error: 'First name, last name, class and term fee are required.' });

  const db = readDB();
  const student = {
    id: uid(),
    schoolId: req.schoolId,
    firstName,
    lastName,
    className,
    termFee: parseFloat(termFee),
    parentName: parentName || '',
    parentPhone: parentPhone || '',
    // Unique payment reference for Flutterwave link
    paymentRef: `TUT-${uid().toUpperCase()}`,
    createdAt: new Date().toISOString(),
  };
  db.students.push(student);
  writeDB(db);
  res.json({ student });
});

app.delete('/api/students/:id', requireAuth, (req, res) => {
  const db = readDB();
  const student = db.students.find(s => s.id === req.params.id && s.schoolId === req.schoolId);
  if (!student) return res.status(404).json({ error: 'Student not found' });
  db.students = db.students.filter(s => s.id !== req.params.id);
  db.payments = db.payments.filter(p => p.studentId !== req.params.id);
  writeDB(db);
  res.json({ ok: true });
});

// ═══════════════════════════════════════════════════════════
// PAYMENT ROUTES
// ═══════════════════════════════════════════════════════════

app.get('/api/payments', requireAuth, (req, res) => {
  const db = readDB();
  const payments = db.payments
    .filter(p => p.schoolId === req.schoolId)
    .sort((a, b) => new Date(b.paidAt) - new Date(a.paidAt));
  res.json({ payments });
});

// Manual payment (cash or any manual entry)
app.post('/api/payments', requireAuth, (req, res) => {
  const { studentId, amount, method, note, paidAt } = req.body;
  if (!studentId || !amount || !method)
    return res.status(400).json({ error: 'Student, amount and method are required.' });

  const db = readDB();
  const student = db.students.find(s => s.id === studentId && s.schoolId === req.schoolId);
  if (!student) return res.status(404).json({ error: 'Student not found' });

  const payment = {
    id: uid(),
    schoolId: req.schoolId,
    studentId,
    studentName: `${student.firstName} ${student.lastName}`,
    parentName: student.parentName,
    parentPhone: student.parentPhone,
    amount: parseFloat(amount),
    method,
    note: note || '',
    source: 'manual',
    paidAt: paidAt || new Date().toISOString(),
    createdAt: new Date().toISOString(),
  };
  db.payments.push(payment);
  writeDB(db);
  res.json({ payment });
});

app.delete('/api/payments/:id', requireAuth, (req, res) => {
  const db = readDB();
  const payment = db.payments.find(p => p.id === req.params.id && p.schoolId === req.schoolId);
  if (!payment) return res.status(404).json({ error: 'Payment not found' });
  db.payments = db.payments.filter(p => p.id !== req.params.id);
  writeDB(db);
  res.json({ ok: true });
});

// ═══════════════════════════════════════════════════════════
// FLUTTERWAVE WEBHOOK
// POST /webhooks/flutterwave
// Called automatically by Flutterwave when a payment is made
// ═══════════════════════════════════════════════════════════
app.post('/webhooks/flutterwave', (req, res) => {
  // 1. Verify the request is genuinely from Flutterwave
  const signature = req.headers['verif-hash'];
  if (!signature || signature !== CONFIG.FLW_SECRET_HASH) {
    console.warn('[FLW] Webhook rejected — invalid signature');
    return res.status(401).send('Unauthorized');
  }

  let event;
  try {
    event = JSON.parse(req.body.toString());
  } catch (e) {
    return res.status(400).send('Bad JSON');
  }

  // 2. Only process successful charge events
  if (event.event !== 'charge.completed' || event.data?.status !== 'successful') {
    return res.status(200).send('Ignored');
  }

  const data = event.data;
  const txRef = data.tx_ref; // This is the student's paymentRef we set when creating the link

  const db = readDB();

  // 3. Find the student by their unique payment reference
  const student = db.students.find(s => s.paymentRef === txRef);
  if (!student) {
    console.warn(`[FLW] No student found for tx_ref: ${txRef}`);
    return res.status(200).send('Student not found — logged');
  }

  // 4. Prevent duplicate webhook processing
  const alreadyLogged = db.payments.find(p => p.flwTransactionId === String(data.id));
  if (alreadyLogged) {
    return res.status(200).send('Duplicate — already recorded');
  }

  // 5. Auto-log the payment
  const payment = {
    id: uid(),
    schoolId: student.schoolId,
    studentId: student.id,
    studentName: `${student.firstName} ${student.lastName}`,
    parentName: data.customer?.name || student.parentName,
    parentPhone: data.customer?.phone_number || student.parentPhone,
    amount: parseFloat(data.amount),
    method: data.payment_type === 'card' ? 'Card (Flutterwave)'
          : data.payment_type === 'banktransfer' ? 'Bank Transfer (Flutterwave)'
          : data.payment_type === 'ussd' ? 'USSD (Flutterwave)'
          : `Online (${data.payment_type})`,
    note: `Auto-logged via Flutterwave. Ref: ${data.flw_ref}`,
    source: 'flutterwave',
    flwTransactionId: String(data.id),
    flwRef: data.flw_ref,
    paidAt: data.created_at || new Date().toISOString(),
    createdAt: new Date().toISOString(),
  };

  db.payments.push(payment);
  writeDB(db);

  console.log(`[FLW] Payment auto-logged: ${payment.studentName} — NGN ${payment.amount}`);
  res.status(200).send('Recorded');
});

// ═══════════════════════════════════════════════════════════
// MONO WEBHOOK
// POST /webhooks/mono
// Called by Mono when a new credit hits the school's linked bank account
// ═══════════════════════════════════════════════════════════
app.post('/webhooks/mono', (req, res) => {
  // 1. Verify Mono signature
  const monoSignature = req.headers['mono-webhook-secret'];
  if (!monoSignature || monoSignature !== CONFIG.MONO_WEBHOOK_SECRET) {
    console.warn('[MONO] Webhook rejected — invalid signature');
    return res.status(401).send('Unauthorized');
  }

  let event;
  try {
    event = JSON.parse(req.body.toString());
  } catch (e) {
    return res.status(400).send('Bad JSON');
  }

  // 2. Only handle new credit transactions
  if (event.event !== 'mono.events.account_updated') {
    return res.status(200).send('Ignored');
  }

  const transactions = event.data?.transactions || [];
  const db = readDB();

  // 3. Find which school this Mono account belongs to
  const school = db.schools.find(s => s.monoAccountId === event.data?.account?._id);
  if (!school) {
    console.warn('[MONO] No school matched for Mono account:', event.data?.account?._id);
    return res.status(200).send('School not found');
  }

  // 4. Process each new credit transaction
  let recorded = 0;
  for (const tx of transactions) {
    if (tx.type !== 'credit') continue; // Only credits (money coming in)

    const alreadyLogged = db.payments.find(p => p.monoTxId === tx._id);
    if (alreadyLogged) continue;

    // Try to match the narration/description to a student name or paymentRef
    const narration = (tx.narration || '').toLowerCase();
    const students = db.students.filter(s => s.schoolId === school.id);

    let matchedStudent = null;

    // Try matching payment reference first (most reliable)
    matchedStudent = students.find(s => narration.includes(s.paymentRef.toLowerCase()));

    // Fall back: match by student name in narration
    if (!matchedStudent) {
      matchedStudent = students.find(s =>
        narration.includes(s.firstName.toLowerCase()) &&
        narration.includes(s.lastName.toLowerCase())
      );
    }

    // Fall back: match by parent name
    if (!matchedStudent) {
      matchedStudent = students.find(s =>
        s.parentName && narration.includes(s.parentName.toLowerCase().split(' ')[0])
      );
    }

    const payment = {
      id: uid(),
      schoolId: school.id,
      studentId: matchedStudent?.id || null,
      studentName: matchedStudent
        ? `${matchedStudent.firstName} ${matchedStudent.lastName}`
        : 'Unmatched — Review Required',
      parentName: matchedStudent?.parentName || '',
      parentPhone: matchedStudent?.parentPhone || '',
      amount: parseFloat(tx.amount) / 100, // Mono returns amount in kobo
      method: 'Bank Transfer (Mono)',
      note: `Narration: ${tx.narration}. Auto-logged via Mono.`,
      source: 'mono',
      monoTxId: tx._id,
      requiresReview: !matchedStudent,
      paidAt: tx.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    db.payments.push(payment);
    recorded++;
    console.log(`[MONO] Transaction recorded: ${payment.studentName} — NGN ${payment.amount}`);
  }

  writeDB(db);
  res.status(200).json({ recorded });
});

// ═══════════════════════════════════════════════════════════
// FLUTTERWAVE PAYMENT LINK GENERATOR
// Returns the URL for a student's payment link
// ═══════════════════════════════════════════════════════════
app.get('/api/students/:id/payment-link', requireAuth, (req, res) => {
  const db = readDB();
  const student = db.students.find(s => s.id === req.params.id && s.schoolId === req.schoolId);
  if (!student) return res.status(404).json({ error: 'Student not found' });

  const school = db.schools.find(s => s.id === req.schoolId);

  // Build the Flutterwave inline payment URL
  // In production this uses the school's own FLW public key
  const paymentLink = `https://checkout.flutterwave.com/v3/hosted/pay?` + new URLSearchParams({
    public_key: school.flwPublicKey || CONFIG.FLW_SECRET_KEY.replace('SEC', 'PUB'),
    tx_ref: student.paymentRef,
    amount: student.termFee,
    currency: 'NGN',
    payment_options: 'card,banktransfer,ussd',
    customer_email: `${student.paymentRef}@tuit.school`,
    customer_phone_number: student.parentPhone,
    customer_name: student.parentName || `Parent of ${student.firstName}`,
    meta_student_id: student.id,
    meta_student_name: `${student.firstName} ${student.lastName}`,
    redirect_url: `${req.protocol}://${req.get('host')}/payment-success`,
    title: `${school.schoolName} — School Fees`,
    description: `Term fee payment for ${student.firstName} ${student.lastName} (${student.className})`,
  }).toString();

  res.json({ paymentLink, paymentRef: student.paymentRef });
});

// ═══════════════════════════════════════════════════════════
// DASHBOARD STATS
// ═══════════════════════════════════════════════════════════
app.get('/api/dashboard', requireAuth, (req, res) => {
  const db = readDB();
  const students = db.students.filter(s => s.schoolId === req.schoolId);
  const payments = db.payments.filter(p => p.schoolId === req.schoolId);

  const paidMap = {};
  payments.forEach(p => {
    if (p.studentId) paidMap[p.studentId] = (paidMap[p.studentId] || 0) + p.amount;
  });

  const totalCollected = payments.reduce((sum, p) => sum + p.amount, 0);
  let fullyPaid = 0, partial = 0, owing = 0, outstandingAmount = 0;

  students.forEach(s => {
    const paid = paidMap[s.id] || 0;
    if (paid >= s.termFee) fullyPaid++;
    else if (paid > 0) { partial++; outstandingAmount += s.termFee - paid; }
    else { owing++; outstandingAmount += s.termFee; }
  });

  const requiresReview = payments.filter(p => p.requiresReview).length;
  const recentPayments = [...payments]
    .sort((a, b) => new Date(b.paidAt) - new Date(a.paidAt))
    .slice(0, 20);

  res.json({
    totalCollected,
    totalStudents: students.length,
    fullyPaid,
    partial,
    owing,
    outstandingAmount,
    totalTransactions: payments.length,
    requiresReview,
    recentPayments,
  });
});

// ─── Start ────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`Tuit server running on http://localhost:${PORT}`);
  console.log(`Flutterwave webhook: POST http://localhost:${PORT}/webhooks/flutterwave`);
  console.log(`Mono webhook:        POST http://localhost:${PORT}/webhooks/mono`);
});
